#!/usr/bin/python2.6
#
# Copyright (C) 2013  Carbonite, Inc.  All rights reserved.
#

from carbonite_monitoring import monitor_loop

monitor_loop()
