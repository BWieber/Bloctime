#
# Copyright (C) 2013  Carbonite, Inc.  All rights reserved.
#

import time, logging, subprocess, getpass, sqlite3, StringIO
import plistlib
from collections import namedtuple, defaultdict
from sys import stdout, stderr
from os import listdir, getpid
import urllib2, json 

def ts_str(tt=None):
  if not tt:
    tt=time.time()
  ts=time.localtime(tt)
  return time.strftime("%Y-%m-%dT%H:%M:%S.",ts)+"%03d"%(int((tt%1)*1000),)

try:
  import psutil
except ImportError:
  import os.path
  import sys
  wd=os.path.dirname(sys.argv[0])
  psutildir = os.path.dirname(wd)+'/psutil'
  sys.path.append(psutildir)
  try:
    import psutil
  except ImportError:
    s=psutildir+" did not contain psutil!!!!!"
    print s
    print >> stderr, "ERROR {0} [monitor] {1}".format(ts_str(),s)
    exit(255)

def plist_read(filename):
  """Get a dict from a plist file if possible.

  Will attempt to convert to XML if the file is unreadable."""
  try:
    return plistlib.readPlist(filename)
  except:
    args = ['plutil','-convert','xml1','-o','-',filename]
    try:
      p = subprocess.Popen(args,stdout=subprocess.PIPE)
      return plistlib.readPlist(StringIO.StringIO(p.communicate()[0]))
    except:
      return defaultdict(bool)

overrides_plist = plist_read('/Library/Preferences/com.carbonite.monitor.plist')

# default settings
MONITOR_PERIOD = 60
MONITOR_BACKOFF = 0.2
CPU_THRESHOLD = 150
MEM_THRESHOLD = 50
PID_THRESHOLD = 10
PID_AGE_LIMIT = 86400
CARBONITE_EVENTS_FIRST_CUTOFF = 86400
CARBONITE_EVENTS_SECOND_CUTOFF = CARBONITE_EVENTS_FIRST_CUTOFF * 7
CARBONITE_EVENTS_PATH = '/Library/Application Support/Carbonite/Data/CarboniteEvents.db'
CARBONITE_LOG_PATH = '/Library/Logs/Carbonite/Carbonite.log'
MONITOR_LOG_PATH = '/Library/Logs/Carbonite/MonitorStats.csv'
MONITOR_BACKOFF_REMAINDER = (1-MONITOR_BACKOFF) 
LOG_LINES_TO_REPORT = 20
REPORT_SAMPLE_TIME = 10
REPORT_SAMPLE_MESSAGE_FILE = stderr
RELOAD_TIMEOUT_SECONDS = 2 * 24 * 60 * 60   # 2 days

# overrides
overrides = dict()
if 'monitorPeriod' in overrides_plist:
  MONITOR_PERIOD = overrides_plist['monitorPeriod']
  overrides['MONITOR_PERIOD'] = MONITOR_PERIOD
if 'monitorBackoff' in overrides_plist:
  MONITOR_BACKOFF = overrides_plist['monitorBackoff']
  overrides['MONITOR_BACKOFF'] = MONITOR_BACKOFF
if 'cpuThreshold' in overrides_plist:
  CPU_THRESHOLD = overrides_plist['cpuThreshold']
  overrides['CPU_THRESHOLD'] = CPU_THRESHOLD
if 'memThreshold' in overrides_plist:
  MEM_THRESHOLD = overrides_plist['memThreshold']
  overrides['MEM_THRESHOLD'] = MEM_THRESHOLD
if 'pidThreshold' in overrides_plist:
  PID_THRESHOLD = overrides_plist['pidThreshold']
  overrides['PID_THRESHOLD'] = PID_THRESHOLD
if 'pidAgeLimit' in overrides_plist:
  PID_AGE_LIMIT = overrides_plist['pidAgeLimit']
  overrides['PID_AGE_LIMIT'] = PID_AGE_LIMIT
if 'reloadTimeoutSeconds' in overrides_plist:
  RELOAD_TIMEOUT_SECONDS = overrides_plist['reloadTimeoutSeconds']
  overrides['RELOAD_TIMEOUT_SECONDS'] = RELOAD_TIMEOUT_SECONDS  

# show overrides at startup
if len(overrides) > 0:
  os = "; ".join(map(lambda c: "{0} = {1}".format(c,overrides[c]),overrides))
  print >> stderr, "INFO {0} [monitor] overrides: {1}".format(ts_str(),os)

# keep track of processes which we've unloaded, what user they were, and when we
# unloaded them, so that we can reload them after RELOAD_TIMEOUT_SECONDS
UnloadedProcess=namedtuple('UnloadedProcess',('label','user','time_unloaded'))
unloadedProcessList = []

logging.basicConfig(format="%(message)s",stream=stdout)
pelog=logging.getLogger('carbonite_monitor')
pelog.setLevel(logging.INFO)
pecols=('name','pid','time','pct_cpu','pct_mem')

ProcessEntry = namedtuple('ProcessEntry',pecols)

def pid_process(pid):
  """Get a psutil.Process from a pid if possible, None otherwise."""
  try:
    return psutil.Process(pid)
  except psutil.error.NoSuchProcess:
    return None

def carbonite_processes():
  """Get the Carbonite processes and launchd entries."""
  def _launchctl_process_list(args,user):
    launchctl=subprocess.Popen(args,stdout=subprocess.PIPE)
    res,err=launchctl.communicate()
    if( err and len(err) > 0 ):
      raise err
    llist=res.split("\n")[1:]
    llist=map(lambda s:s.split("\t"),llist)
    if len(llist[-1]) < 3:
      llist=llist[:-1]
    llist=map(lambda (pid,status,label): (pid,label), llist)
    llist=filter(lambda (pid,label):label.startswith('com.carbonite'),llist)
    pl2plu=lambda (p,l):(None if p == '-' else pid_process(int(p)),l,user)
    plulist=map(pl2plu,llist)
    return plulist
  # carbonite processes running as users
  plist=map(pid_process,psutil.get_pid_list())
  def _pfilter(p):
    if( not p ):
      return False
    try:
      return p.name.startswith('Carbonite')
    except psutil.error.NoSuchProcess:
      return False
  plist=filter(_pfilter,plist)
  users=set(map(lambda p:p.username,plist))
  plulist = []
  for user in users:
    args = ['sudo','-u',user,'launchctl','list']
    plulist.extend(_launchctl_process_list(args,user))
  return plulist

def obtain_osx_version():
  """Obtain the Mac OSX version number"""
  sp=subprocess.Popen(['sw_vers','-productVersion'],stdout=subprocess.PIPE)
  res,_ = sp.communicate()
  return  res.rstrip()

def save_process_info_after_unloading(process_info):
  """After a process is unloaded, save enough information so we can reload it later"""
  # don't allow more than one entry for the same process
  remove_process_info_after_reloading(process_info.label)
  
  unloadedProcessList.append(process_info)

def remove_process_info_after_reloading(label):
  """After a process is reloaded, we don't have to save any information about the process"""
  global unloadedProcessList
  unloadedProcessList = [proc for proc in unloadedProcessList if proc.label != label]

def plwatch(process,label):
  """Watch the psutil.Process and return a ProcessEntry."""
  name=label.rpartition('carbonite.')[-1]
  try:
    pid=process.pid
    pct_cpu=process.get_cpu_percent(interval=2.5)
    ts=time.time()
    pct_mem=process.get_memory_percent()
    pct_cpu=(pct_cpu + process.get_cpu_percent(interval=2.5))/2.0
  except (psutil.error.NoSuchProcess,AttributeError):
    v=locals()
    if not v.has_key('pid'):
      pid=None
    if not v.has_key('pct_cpu'):
      pct_cpu=None
    if not v.has_key('ts'):
      ts=time.time()
    if not v.has_key('pct_mem'):
      pct_mem=None
  return ProcessEntry(name,pid,ts,pct_cpu,pct_mem)

def preport(fn):
  """Report to carbonite about the state of the carbonite system."""
  def wrap(process,label,*args):
    mypid = getpid()
    mypid_s = str(mypid)
    out_f_n = '/tmp/report-'+mypid_s
    out = open(out_f_n,'w+')
    out.write("-----BEGIN CARBONITE MONITOR REPORT-----\n")
    #decision time stamp
    ts_s = ts_str()
    #supply scores
    my_pid_scores = map(pid_scores,cpu_scores.keys())
    json.dump({'cpu':cpu_scores,'mem':mem_scores,'pid':my_pid_scores},out)
    out.write("\n")
    #get aggregate carboniteevents info
    conn = sqlite3.connect(CARBONITE_EVENTS_PATH)
    curs = conn.cursor()
    cutoffs = (CARBONITE_EVENTS_FIRST_CUTOFF, CARBONITE_EVENTS_SECOND_CUTOFF)
    for cutoff in map(lambda x: time.time()-x,cutoffs):
      errors = dict()
      for table in ('generalerrors','backuperrors','restoreitemerrors'):
        col = 'time' if table == 'generalerrors' else 'lastattempt' 
        curs.execute("""SELECT errorstring, COUNT(*) AS count 
                        FROM %s WHERE ? > ?
                        GROUP BY errorcode""" % table, (col,cutoff) )
        #NB: Tablenames cannot be parametrized http://stackoverflow.com/a/597198
        errors[table] = dict(curs.fetchall())
      json.dump(errors,out)
      out.write("\n")
    del conn, curs, errors
    #get monitor log tail 
    out.write(",".join(pecols))
    out.write("\n")
    out.writelines(open(MONITOR_LOG_PATH,'r').readlines()[-LOG_LINES_TO_REPORT:])
    #get trace if wrapping pkill
    if( process ):
      pid_s = str(process.pid)
      sargs=['sample',pid_s,str(REPORT_SAMPLE_TIME),'-file','/tmp/sample-'+pid_s]
      sample_r = subprocess.call(sargs,stderr=REPORT_SAMPLE_MESSAGE_FILE)
      if( sample_r == 0 ):
        try:
          sample_f = open('/tmp/sample-'+pid_s,'r')
          sample = sample_f.readlines()
          try:
            i = sample.index("Binary Images:\n")
            sample = sample[:i-1]
          except ValueError:
            pass
          out.write("-----BEGIN SAMPLE-----\n")
          out.writelines(sample)
          out.write("-----END SAMPLE-----\n")
        except IOError:
          pass
    out.write("-----END CARBONITE MONITOR REPORT-----\n")
    #push report to PMD (?)
    version = plist_read('../Info.plist')["CFBundleShortVersionString"]
    osx_version = obtain_osx_version()
    reg = plist_read('/Library/Preferences/com.carbonite.carbonite.plist')
    compno = reg["Registry 2"]["CarboniteRegistry"]["Config.ComputerNumber"]
    #perform reportable action
    if( fn(process,label,*args) ):
      if( fn.__name__ == 'pkill' ):
        action = 'killed'
      elif( fn.__name__ == 'pluunload'):
        action = 'unloaded'
      else:
        action = 'did something'
    elif( fn.__name__ == 'pkill' ):
      action = 'stopped' 
    elif( fn.__name__ == 'pluunload'):
      action = 'attempted to unload'
    else:
      action = 'did something to'
    #summary line (to include stop/kill/unload)
    summary="Monitor {0} {1} for {2}".format(action,label,"some reason")
    #include summary line in report
    url_summary = "%20".join(summary.split(' '))
    #TODO split line
    pmd_url_tpl = 'https://client-feedback.carbonite.com/CustomerSupport/diagnostics.aspx?mode=monitor&sense={0}&carbver={1}&admin=1&cpu=0&osver={2}&iever=monitor&compno={3}&email=anonymous@carbonite.com'
    pmd_url = pmd_url_tpl.format(url_summary,version,osx_version,compno)
    #write full report to Carbonite.log
    out.close()
    with open(CARBONITE_LOG_PATH ,'a') as carbonite_log:
      print >> carbonite_log, "ERROR {0} [monitor] {1}".format(ts_s,summary)
      carbonite_log.flush()
      sp = subprocess.Popen(['cat',out_f_n], stdout=carbonite_log)
      try:
        urllib2.urlopen(pmd_url)
      except urllib2.URLError as e:
        ts_s = ts_str()
        print >> stderr, "ERROR {0} [monitor] {1}".format(ts_s,e)
        print >> stderr, "ERROR {0} [monitor] URL: {1}".format(ts_s,pmd_url)
      finally:
        sp.wait()
        carbonite_log.close()
  return wrap

@preport
def pkill(process,label):
  """Kill the psutil.Process in a sane manner."""
  try:
    process.terminate()
    process.wait(timeout=30) 
  except psutil.error.TimeoutExpired:
    process.kill()
    return True
  except psutil.error.NoSuchProcess:
    pass
  return False

def lupath(label,username):
  """Find the plist path given a launchd label and a username."""
  lparts = label.split('.')
  def _plist_label_match_fn(filename):
    """Check whether the filename matches the label

    Breaks both apart into their dot-separated components and verifies that
    every part in the filename except for "launchd" and "plist" is present in
    the label, in order."""
    fparts = filename.split('.')
    last_i=0
    for part in fparts:
      if part not in set(('launchd','plist',)):
        try:
          i = lparts.index(part)
        except ValueError:
          return False
        if i < last_i:
          return False
        last_i = i
    return True 
  for dirname in ('/Library/LaunchDaemons/', '/Library/LaunchAgents/'):
    filenames = listdir(dirname)
    filenames = filter(lambda fname: fname.startswith('com.carbonite'), filenames)
    try:
      [filename] = filter(_plist_label_match_fn, filenames)
      return dirname+filename
    except ValueError:
      pass
  lupath_err_tpl = "ERROR {0} lupath({1},{2}), filenames={3}"
  print >> stderr, lupath_err_tpl.format(ts_str(),label,username,filenames)

@preport
def pluunload(process,label,username):
  """Unload the psutil.Process from launchd [and alert the user]."""
  #TODO alert the user
  path=lupath(label,username)
  if( path ):
    if( path.startswith('/Library/LaunchDaemons/') ):
      args=["launchctl","unload",path]
    else:
      args=["sudo","-u",username,"launchctl","unload",path]
    res=subprocess.call(args)
    if( res != 0 ):
      pluunload_err_tpl="ERROR {0} Supposed to unload {1} but failed! (args={2}) "
      print >> stderr, pluunload_err_tpl.format(ts_str(), label, args)
      
    # save enough information that we can restart this process later
    save_process_info_after_unloading(UnloadedProcess(label,username,time.time()))
    return True
  else:
    return False

def lureload(label,username):
  """Reload the unloaded process with launchd [and alert the user]."""
  #TODO alert the user
  path=lupath(label,username)
  if( path ):
    if( path.startswith('/Library/LaunchDaemons/') ):
      args=["launchctl","load",path]
    else:
      args=["sudo","-u",username,"launchctl","load",path]
    res=subprocess.call(args)
    if( res != 0 ):
      lureload_err_tpl="ERROR {0} Supposed to load {1} but failed! (args={2}) "
      print >> stderr, lureload_err_tpl.format(ts_str(), label, args)

	# don't try to reload the same process twice
    remove_process_info_after_reloading(label)
    return True
  else:
    return False

def backoff_score(prev,now):
  prev *= MONITOR_BACKOFF_REMAINDER
  return prev + (now or 0.0) * MONITOR_BACKOFF

cpu_scores=defaultdict(int)
def cpu_score(pe):
  """Evaluate the cpu badness of a ProcessEntry against the history."""
  cpu_scores[pe.name] = score = backoff_score(cpu_scores[pe.name],pe.pct_cpu)
  return score

mem_scores=defaultdict(int)
def mem_score(pe):
  """Evaluate the memory badness of a ProcessEntry against the history."""
  mem_scores[pe.name] = score = backoff_score(mem_scores[pe.name],pe.pct_mem)
  return score

pid_sets=defaultdict(set)
pid_ages=dict()
def pid_score(pe):
  """Evaluate the pid badness of a ProcessEntry against the history."""
  the_set=pid_sets[pe.name]
  for pid in the_set.copy():
    if pid_ages[pid] < pe.time - PID_AGE_LIMIT:
      the_set.remove(pid)
      del pid_ages[pid]
  if( pe.pid ):
    the_set.add(pe.pid)
    pid_ages[pe.pid]=pe.time
  return len(the_set)

def pid_scores(pn):
  return len(pid_sets[pn])

def pe_scores(pe,*score_fns):
  """Evaluate a badnesses of a ProcessEntry."""
  if( not pe ):
    return map(lambda fn:0,score_fns)
  def score( score_fn ):
    return score_fn(pe)
  return map(score,score_fns)

def pedump(val):
  """Dumps a value from a ProcessEntry to a string, quoted if appropriate."""
  res=str(val)
  if( "," not in res ):
    return res
  if( '"' not in res ):
    return '"'+res+'"'
  return '"'+'""'.join(res.split('"'))+'"'

def pesave(pe):
  """Persists a ProcessEntry to the (csv) datastore."""
  if pe:
    pelog.info(",".join(map(pedump,pe)))

def monitor_loop_iter():
  """Perform an iteration of the monitor loop."""
  processes,labels,users=zip(*carbonite_processes())
  pentries=map(plwatch,processes,labels)
  scores=dict()
  for (i,pentry) in enumerate(pentries):
    pesave(pentry)
    (cs,ms,ps)=pe_scores(pentry,cpu_score,mem_score,pid_score)
  for (i,pentry) in enumerate(pentries):
    pn=pentry.name
    (cs,ms,ps)=(cpu_scores[pn],mem_scores[pn],pid_scores(pn))
    if processes[i] and cs > CPU_THRESHOLD or ms > MEM_THRESHOLD:
      pkill(processes[i],labels[i])
      del cpu_scores[pentry.name]
      del mem_scores[pentry.name]
    if ps > PID_THRESHOLD:
      pluunload(processes[i],labels[i],users[i])
      for pid in pid_sets[pentry.name]:
        del pid_ages[pid]
      del pid_sets[pentry.name]
    
  # check if there any processes that were unloaded but that we want to reload
  # now that a timeout has passed
  now = time.time()
  for proc in unloadedProcessList:
    if (now > proc.time_unloaded + RELOAD_TIMEOUT_SECONDS):
      lureload(proc.label, proc.user)

def monitor_loop():
  pelog.info(",".join(pecols))
  while(True):
    then = time.time()
    monitor_loop_iter()
    now = time.time()
    time.sleep(max(MONITOR_PERIOD - then + now,0))
